<?php
	/* les variables qui vont servires à la configuration de la base de donnees */
	$host='localhost';
	$dbname='db_miniquiz';
	$user='root';
	$password='';
	
?>
