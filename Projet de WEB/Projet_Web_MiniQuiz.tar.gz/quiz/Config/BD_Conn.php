<?php
	
	/* on inclut les variables de parametrage de la connexion a la base de donnees*/
	require_once 'Config.php';
	
	
	// connexion à Mysql sans base de données
	$dbh = new PDO('mysql:host='.$host, $user, $password);
		 
	// création de la requête sql
	// on teste avant si elle existe ou non (par sécurité)
	$requete = "CREATE DATABASE IF NOT EXISTS `".$dbname."` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci";
		 
	// on prépare et on exécute la requête
	$dbh->prepare($requete)->execute();

	try
		{
			/* Connexion avec la base de donnees*/
			$dbh = new PDO('mysql:host='.$host.';dbname='.$dbname.'', $user, $password);
			
			/* creation de la table membre si elle n'exite pas deja */
			$table_membre = $dbh->query("CREATE TABLE IF NOT EXISTS `membre` 
			(`email` varchar(20) NOT NULL,`pseudo` varchar(30) NOT NULL,`nom` varchar(50) NOT NULL,
			`prenom` varchar(50) NOT NULL,`password` varchar(255) NOT NULL,PRIMARY KEY (`email`))
			ENGINE=InnoDB DEFAULT CHARSET=utf8"); 
			
			/* verifier si la table membre contient le membre administrateur */
			$rech = $dbh->query("select COUNT(*) from membre where pseudo ='admin'");
			$res = $rech->fetch();
			$count = $res[0];
			
			/* si ce n'est pas le cas le creer a l'installation de la BD */
			if ($count != 1)
			{	
				$admin_membre = $dbh->query("INSERT INTO `membre` (`email`, `pseudo`, `nom`, `prenom`, `password`) 
				VALUES ('admin@mail.com', 'admin', 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3')");
				
				/* Ajout de quelques utilisateur pour pouvoir essayer quelques options comme la suppression ou autres*/
				$add_membre = $dbh->query("INSERT INTO `membre` (`email`, `pseudo`, `nom`, `prenom`, `password`) VALUES
										('christophe@mail.com', 'christophe15', 'christophe', 'colomb', 'b9e9b78d0e5108b89c3f9f0efcba13e7'),
										('nabil@mail.com', 'nabil', 'nabil', 'nabil', '070aa66550916626673f492bdbdb655f'),
										('rouen@mail.com', 'univ-rouen', 'rouen', 'rouen', '25d22f3af7842c3206e3d5dcd4a373b6'),
										('tintin@mail.com', 'tintin', 'tintin', 'tintin', '069a6a9ccaaca7967a0c43cb5e161187')");
			}
			
			/* creation de la table membre_acces si elle n'exite pas deja */
			$table_membre_acces = $dbh->query("CREATE TABLE IF NOT EXISTS `membre_acces` 
			(`login` varchar(30) NOT NULL,`password` varchar(255) NOT NULL,PRIMARY KEY (`login`))
			ENGINE=InnoDB DEFAULT CHARSET=utf8");
			
			/* verifier si la table membre_acces contient le membre administrateur */
			$rech2 = $dbh->query("select COUNT(*) from membre_acces where login ='admin'");
			$res2 = $rech2->fetch();
			$count1 = $res2[0];
			
			/* si ce n'est pas le cas le creer a l'installation de la BD */
			if ($count1 != 1)
			{	
				$admin_membre_acces = $dbh->query("INSERT INTO `membre_acces` (`login`, `password`) 
				VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3')");
				
				/* Ajout de quelques utilisateur pour pouvoir essayer quelques options comme la suppression ou autres*/
				$admin_membre_acces = $dbh->query(" INSERT INTO `membre_acces` (`login`, `password`) VALUES
													('christophe15', 'b9e9b78d0e5108b89c3f9f0efcba13e7'),
													('nabil', '070aa66550916626673f492bdbdb655f'),
													('tintin', '069a6a9ccaaca7967a0c43cb5e161187'),
													('univ-rouen', '25d22f3af7842c3206e3d5dcd4a373b6')
				");
				
			}
			
			/* creation de la table quiz si elle n'exite pas deja */
			$table_quiz = $dbh->query("CREATE TABLE IF NOT EXISTS `quiz` (`id` int(11) NOT NULL AUTO_INCREMENT,`nom` varchar(50) NOT NULL,`proprietaire` varchar(50) NOT NULL,PRIMARY KEY (`id`)) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0");
			
			/* verifier si la table QUIZ contient est vide */
			$rech2 = $dbh->query("select COUNT(*) from quiz");
			$res2 = $rech2->fetch();
			$count1 = $res2[0];
			
			if ($count1 != 1)
			{
				$ajout_quiz = $dbh->query("	INSERT INTO `quiz` (`id`, `nom`, `proprietaire`) VALUES
												(1, 'Géographie', 'christophe15'),
												(2, 'Histoire', 'christophe15'),
												(3, 'HTML_quiz', 'univ-rouen'),
												(4, 'tintin_quiz', 'tintin'),
												(5, 'SVG_quiz', 'univ-rouen'),
												(6, 'MathML_quiz', 'univ-rouen')
				");
			}
			
			/* creation de la table question si elle n'exite pas deja */
			$table_question = $dbh->query("CREATE TABLE IF NOT EXISTS `question` (`id` int(11) NOT NULL AUTO_INCREMENT,`nom_quiz` varchar(50) NOT NULL,`intitule` varchar(100) NOT NULL,`reponse1` varchar(400) NOT NULL,`reponse2` varchar(400) NOT NULL,`reponse3` varchar(400) NOT NULL,`reponse4` varchar(400) NOT NULL,`choix` varchar(2) NOT NULL,PRIMARY KEY (`id`)) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0");
			
			/* verifier si la table question contient est vide */
			$rech2 = $dbh->query("select COUNT(*) from question");
			$res2 = $rech2->fetch();
			$count1 = $res2[0];
			
			if ($count1 != 1)
			{	
				$ajout_question = $dbh->query("
					INSERT INTO `question` (`id`, `nom_quiz`, `intitule`, `reponse1`, `reponse2`, `reponse3`, `reponse4`, `choix`) VALUES
(1, 'Géographie', 'Dans quelle ville se trouve le pont Vasco de Gama ?', 'Lisbonne', 'Madrid', 'Venise ', 'Rome ', '1'),
(2, 'Géographie', 'Quel fleuve traverse la ville de Lyon ?', 'La Garonne ', 'La Seine', 'Le Rhin', 'Le Rhone ', '4'),
(3, 'Géographie', 'Quel est le monument principal de la ville de Reims ?', 'Son obelisque ', 'Son musee ', 'Sa boulangerie ', 'Sa cathedrale ', '4'),
(4, 'Géographie', 'Quelles couleurs figurent sur le drapeau allemand ?', 'Noir - rouge - blanc', 'Noir - rouge - jaune ', 'Noir - vert - jaune', 'Noir - orange - blanc', '2'),
(5, 'Géographie', 'Quelle est la capitale des Philippines ?', 'Jakarta ', 'Wellington ', 'Seoul', 'Manille ', '4'),
(6, 'Géographie', 'Sur quelle Ile peut-on se rendre sur la montagne Pelee ?', 'La Martinique', 'La Guyane ', 'Hawai', 'La Guadeloupe ', '1'),
(7, 'Histoire', 'En quelle année, le III ème Reich a-t-il capitule ?', '1918', '1939 ', '1942', '1945 ', '4'),
(8, 'Histoire', 'En quelle année, Jean-François Champollion a-t-il déchiffré les hieroglyphes de la Pierre de Ro', '1789 ', '1822 ', '1876 ', '1966 ', '2'),
(9, 'Histoire', 'En quelle année, en quelle année ont eu lieu les attentats du 11 septembre ?', '2000 ', '2001 ', '2002', '2003', '2'),
(10, 'Histoire', 'En quelle année, JFK a-t-il ete assassine ?', '1960 ', '1961 ', '1962 ', '1963', '4'),
(11, 'Histoire', 'En quelle année a debuté la Revolution des 3 Glorieuses ?', '1789 ', '1830 ', '1848', '1950', '2'),
(12, 'Histoire', 'En quelle année, Gandhi a-t-il mene sa marche du sel ?', '1889 ', '1900', '1930 ', '1946', '3'),
(13, 'Histoire', 'En quelle année, Louis XIV est-il arrive sur le trone de France ?', '1535 ', '1643', '1699 ', '1725', '2'),
(14, 'Histoire', 'En quelle année eut lieu la bataille de Marignan ?', '1020', '1230', '15151', '1763', '3'),
(15, 'Histoire', 'En quelle année, Hugues Capet a-t-il ete nomme roi de France ?', '987 ', '1200', '1367 ', '1616', '1'),
(20, 'HTML_quiz', 'Quel est le texte souligne ?', '<p><u>Texte souligne</u></p>', '<p>Texte souligne</p>', '<p><i>Texte souligne</i></p>', '<p><b>Texte souligne</b></p>', '1'),
(21, 'HTML_quiz', 'Quel est le texte en gras ?', '<p><u>Texte en gras</u></p>', '<p>Texte en gras</p>', '<p><i>Texte en gras</i></p>', '<p><b>Texte en gras</b></p>', '4'),
(22, 'HTML_quiz', 'Quel est le texte italique ?', '<p><u>Texte en italique</u></p>', '<p>Texte en italique</p>', '<p><i>Texte en italique</i></p>', '<p><b>Texte en italique</b></p>', '3'),
(23, 'HTML_quiz', 'Quel est le texte normal?', '<p><u>Texte normal</u></p>', '<p>Texte normal</p>', '<p><i>Texte normal</i></p>', '<p><b>Texte normal</b></p>', '2'),
(24, 'HTML_quiz', 'que veux dire HTML ?', '<p><b>HypercoolMarkup Language</b></p>', '<p><b>Hypertext Make up Language</b></p>', '<p><b>Hypertext Markup Language</b></p>', '<p><b>Hypertext Markup Lool</b></p>', '3'),
(25, 'tintin_quiz', 'Comment se nomme le chien fidèle de Tintin ?', 'Snoopy ', 'Medor ', 'Woody', 'Milou', '4'),
(26, 'tintin_quiz', 'Quel est le principal defaut de Milou ?', 'La paresse ', 'L\'infidelite ', 'La tentation ', 'La peur ', '3'),
(27, 'tintin_quiz', 'Quel est le nom du superieur hierarchique des Dupondt ?', 'Flaubert ', 'Philibert', 'Aubert', 'Joubert', '4'),
(28, 'tintin_quiz', 'Quel est le prénom du fils archi gaté de l\'emir ?', 'Abdallah', 'Achmed ', 'Abbas ', 'Abdelahak', '1'),
(29, 'tintin_quiz', ' Comment se prénomme le valet du capitaine Haddock au chateau de Moulinsart ?', 'Barnabe ', 'Nestor ', 'Ernest ', 'Fernand ', '2'),
(30, 'tintin_quiz', 'Quel est le prénom de la Castafiore ?', 'Bianca ', 'Gina', 'Rosa', 'Giulia ', '1'),
(31, 'tintin_quiz', 'Quel poeme de Lamartine est recite par coeur par le capitaine Haddock dans le Tresor de Rackham ', 'L Hymne au Soleil ', 'Adieux a la mer ', 'Le Lac', 'Le Vallon ', '3'),
(32, 'tintin_quiz', 'Quelle est la suite de cette celebre replique de Haddock, Mille Millions de Mille ?', 'Pecheurs', 'Babords	', 'Bachi-bouzouks', 'Sabords	', '4'),
(33, 'SVG_quiz', 'Designer le cercle Rouge ?', '<svg height=\"100\" width=\"100\">   <circle cx=\"50\" cy=\"50\" r=\"40\" stroke=\"black\" stroke-width=\"3\" fill=\"yellow\" />   Sorry, your browser does not support inline SVG.   </svg>', '<svg height=\"100\" width=\"100\">   <circle cx=\"50\" cy=\"50\" r=\"40\" stroke=\"black\" stroke-width=\"3\" fill=\"red\" />   Sorry, your browser does not support inline SVG.   </svg> ', '<svg height=\"100\" width=\"100\">   <circle cx=\"50\" cy=\"50\" r=\"40\" stroke=\"black\" stroke-width=\"3\" fill=\"green\" />   Sorry, your browser does not support inline SVG.   </svg>', '<svg height=\"100\" width=\"100\">   <circle cx=\"50\" cy=\"50\" r=\"40\" stroke=\"black\" stroke-width=\"3\" fill=\"white\" />   Sorry, your browser does not support inline SVG.   </svg>', '2'),
(34, 'MathML_quiz', 'La quelle est une la matrice ?', '<math xmlns=\"http://www.w3.org/1998/Math/MathML\"><mrow>			<mrow><msup><mi>x</mi><mn>2</mn></msup><mo>+</mo><mrow><mn>4</mn><mo>⁢</mo><mi>x</mi></mrow><mo>+</mo><mn>4</mn></mrow><mo>=</mo><mn>0</mn></mrow></math>', '<math xmlns=\"http://www.w3.org/1998/Math/MathML\"><mrow><msup><mfenced><mrow><mi>a</mi><mo>+</mo><mi>b</mi></mrow></mfenced><mn>2</mn></msup></mrow> </math>', '<math xmlns=\"http://www.w3.org/1998/Math/MathML\"> 		          <mrow>             <mi>A</mi>             <mo>=</mo> 			             <mfenced open=\"[\" close=\"]\"> 			                <mtable>                   <mtr>                      <mtd><mi>x</mi></mtd>                      <mtd><mi>y</mi></mtd>                   </mtr> 					                   <mtr>                      <mtd><mi>z</mi></mtd>     ', '<math xmlns=\"http://www.w3.org/1998/Math/MathML\">     <mrow>       <mrow>         <msup>           <mi>a</mi>           <mn>2</mn>         </msup>         <mo>+</mo>         <msup>           <mi>b</mi>           <mn>2</mn>         </msup>       </mrow>       <mo>=</mo>       <msup>         <mi>c</mi>         <mn>2</mn>       </msup>     </mrow>   </math>', '3')

				");
		
			}
		}
		catch(PDOException $e)
		{
			/* En cas de probleme avec la connexion de la BD ce message d'erreur s'affichera */
			Die ( 'Erreur  au niveau de la BDD ');
		}
?>
