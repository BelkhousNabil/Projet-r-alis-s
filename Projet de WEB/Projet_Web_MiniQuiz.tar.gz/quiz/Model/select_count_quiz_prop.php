<?php
	
	/*  afficher que les quiz du proprietaire pour les modifiers */
	$resultrech = $dbh->query("select COUNT(*) from quiz where nom ='".$nameq."' and proprietaire='$prop'");   
	
	$result = $resultrech->fetch();
	$count = $result[0];
?>