<?php
	
	/* recuperer nom de chaque quiz */
	$resultrech2 = $dbh->query("select nom from quiz where proprietaire='$login'");

?>