<?php
	
	/* inserer dans les deux table et rediriger vers la page d'acceuil avec un message de confirmation*/
	$resultrech2 = $dbh->query("insert into membre values('$email','$pseudo','$nom','$prenom','$password')");
	$resultrech3 = $dbh->query("insert into membre_acces values('$pseudo','$password')");
?>