<?php
	
	/* recuperer les questions est leurs reponses qui corresponde a ce quiz */
	$champs = $dbh->query("select intitule,reponse1,reponse2,reponse3,reponse4,choix from question where nom_quiz ='".$quiz."'");   
		
?>