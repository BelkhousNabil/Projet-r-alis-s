<?php
	
	/* verifier si un quiz a deja ce nom */
	$rech = $dbh->query("select COUNT(*) from quiz where nom ='".$nameq."'");
	$res = $rech->fetch();
	$count = $res[0];

?>