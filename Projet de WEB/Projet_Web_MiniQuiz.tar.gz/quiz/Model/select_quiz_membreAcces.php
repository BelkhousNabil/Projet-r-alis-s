<?php
	
	/* recuperer le pseudo de tout les comptes sauf l'admin */
	$resultrech = $dbh->query("select login from membre_acces where login<>'admin'");  
	
	/* recuperer nom et le proprietaire de chaque quiz */
	$resultrech2 = $dbh->query("select nom,proprietaire from quiz ");

?>