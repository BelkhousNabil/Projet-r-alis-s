<?php
	
	/* verifier si le mail ne correspond a aucun de ceux de la BD*/
	$resultrech = $dbh->query("select COUNT(*) from membre where email ='".$email."'");
	$result = $resultrech->fetch();
	$count=0;
	$count = $result[0];
	
	/* verifier si le pseudo ne correspond a aucun de ceux de la BD*/
	$resul = $dbh->query("select COUNT(*) from membre_acces where login ='".$pseudo."'");
	$res = $resul->fetch();
	$count1 = $res[0];

	
?>