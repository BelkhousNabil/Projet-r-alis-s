<?php
	
	/* recuperer le nombre de question dans ce quiz */
	$resultrech = $dbh->query("select COUNT(*) from question where nom_quiz ='".$quiz."'");
	$result = $resultrech->fetch();
	$count = $result[0];

?>