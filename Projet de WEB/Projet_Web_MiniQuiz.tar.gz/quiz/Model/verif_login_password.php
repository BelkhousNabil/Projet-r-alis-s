<?php
	
	/* verifier que le login et le mode de passee existe */
	$resultrech = $dbh->query("select COUNT(*) from membre_acces where login ='".$login."'&& password='".$password."'");   
	$result = $resultrech->fetch();
	$count = $result[0];

?>