<?php
	
	$resultrech2 = $dbh->query("select nom from quiz ");
	$resultrech3 = $dbh->query("select count(*) from quiz ");
	$res = $resultrech3->fetch();
	$coun=$res[0];
	
?>