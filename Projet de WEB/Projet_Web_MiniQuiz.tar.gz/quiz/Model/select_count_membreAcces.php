<?php
	
	/* selectionner tout les login sauf celui de l'administrateur pour les mettre dans la liste deroulante */
	$resultrech2 = $dbh->query("select login from membre_acces where login <> 'admin'");
	
	$resu = $dbh->query("select count(*) from membre_acces where login <> 'admin'");
	$res = $resu->fetch();
	$coun=$res[0];

?>