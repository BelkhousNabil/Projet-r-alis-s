<?php
	
	/*  inserer dans la table quiz */
	$ajout_quiz = $dbh->query("insert into quiz values('','$nameq','$proprietaire')");
	
?>