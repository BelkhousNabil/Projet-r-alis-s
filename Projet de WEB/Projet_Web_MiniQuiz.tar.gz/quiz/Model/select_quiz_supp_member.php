<?php
	
	/* sinon afficher que les quiz de cette utilisateur pour qu'il puisse choisir qui supprimier */
	$resultrech2 = $dbh->query("select nom from quiz where proprietaire='$prop'");
	$resultrech3 = $dbh->query("select count(*) from quiz where proprietaire='$prop'");
	$res = $resultrech3->fetch();
	$coun=$res[0];
	
?>