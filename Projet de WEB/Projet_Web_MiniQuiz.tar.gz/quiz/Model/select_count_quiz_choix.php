<?php
	
	/* selectionner les noms de quiz pour les afficher dans une liste deroulente*/
	$resultrech2 = $dbh->query("select nom from quiz ");
	
	$resu = $dbh->query("select count(*) from quiz");
	$res = $resu->fetch();
	$coun=$res[0];

?>