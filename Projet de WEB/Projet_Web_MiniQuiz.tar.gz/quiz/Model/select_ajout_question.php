<?php
	
	/* compter le nombre de question pour le quiz */
	$nbr = $dbh->query("select COUNT(*) from question where nom_quiz ='".$nameq."'");   
	$resultnbr = $nbr->fetch();
	$countnbr = $resultnbr[0];

	/* recuperer les questions et leurs reponses et la bonne reponse et son id et la bonne reponse  */
	$champs = $dbh->query("select intitule,reponse1,reponse2,reponse3,reponse4,choix,id from question where nom_quiz ='".$nameq."'"); 
		
?>