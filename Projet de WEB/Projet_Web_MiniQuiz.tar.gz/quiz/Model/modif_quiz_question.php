<?php
	
	/* recuperer les quiz du proprietaire */
	$resultrech2 = $dbh->query("select nom from quiz where proprietaire='$prop'");
	
	$resultrech3 = $dbh->query("select count(*) from quiz where proprietaire='$prop'");
	$res = $resultrech3->fetch();
	$coun=$res[0];

?>