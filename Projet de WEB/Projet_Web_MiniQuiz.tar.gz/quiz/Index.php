﻿<?php
	/* inclure la connexion a la BD, lors de chaque acces, si c'est la prmiere fois, la BD sera deployee automatiquement */
	require_once 'Config/BD_Conn.php';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Mini Quiz</title>
    <link href="Style/style_Acceuil.css" rel="stylesheet">
	<link rel="stylesheet" media="screen and (max-width: 1000px) and (min-width: 870px)" href="Style/style_menu-deux1.css" />
	<link rel="stylesheet" media="screen and (max-width: 869px) and (min-width: 550px)" href="Style/style_menu-deux2.css" />
	<link rel="stylesheet" media="screen and (max-width: 549px) and (min-width: 350px)" href="Style/style_menu-deux3.css" />

  </head>

  <body>
  	<nav>
  		<ul> 
			<li class = "vide"> </li>
  			<li> <a href="Controller/choix_quiz.php">Mini Quiz</a> </li>
			<li class = "vide"> </li>
  			<li> <a href="Acceuil.php">Se connecter</a> </li>
			<li class = "vide"> </li>
  			<li> <a href="View/Inscription.html">S'inscrir</a> </li>
  		</ul>
  	</nav>

	<fieldset>
		<legend> Connexion  </legend>
			<form method = "GET" action = "Controller/membre.php" name = "form_connexion">
				 
				<div class = "div-ligne">
					<div class = "div-gauche">
						<label for='log'>Login</label>
					</div>
					<div class = "div-droit">
						<input type="text" id="log" name="log" maxlength ="30">
					</div>
				</div>		
				<div class = "div-ligne">
					<div class = "div-gauche">
						<label for='mp'>Mot de passe</label>
					</div>
					<div class = "div-droit">
						<input type="password" id="mp" name="mp" > 
					</div>
				</div>	

              	<input type='submit' name='conex' id='conex' value=" Connexion"  >

						
			</form>
	</fieldset>
    
  </body>
</html>

