<?php
	session_start();
	
	require_once '../Config/BD_Conn.php';
	
	/* recuperer le nombre de question, toutes les bonnes reponses, et les questions pour faire la correction du quiz */
	$nbrquestion=$_SESSION['nbrquestion'];
	$reponse=$_SESSION['reponse'];
	$rep=$_SESSION['rep'];
	$questions=$_SESSION['questions'];
	
	/* variable qui va nous calculer le resultat */
	$resultat=0;
	
	$i=1;$j=0;
	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Mini Quiz</title>
    <link href="../Style/style_Acceuil.css" rel="stylesheet">
	<link rel="stylesheet" media="screen and (max-width: 869px) and (min-width: 710px)" href="../Style/style_creat_quiz1.css" />
	<link rel="stylesheet" media="screen and (max-width: 709px) and (min-width: 550px)" href="../Style/style_creat_quiz2.css" />
	<link rel="stylesheet" media="screen and (max-width: 549px) and (min-width: 350px)" href="../Style/style_creat_quiz3.css" />
    
  </head>

  <body>
  	<nav>
  		<?php	
			echo("<ul>");
				echo("<li class = \"vide\"> </li>");
				echo("<li> <a href=\"choix_quiz.php\">Mini Quiz</a> </li>");
				echo("<li class = \"vide\"> </li>");
				echo("<li class = \"li_gest\"> <a href=\"redirection.php\"> Acceuil </a> </li>");
				echo("<li class = \"vide\"> </li>");
			echo("</ul>");
		?>
  	</nav>

	<fieldset class = "fied_result">
		<legend> Resultat Quiz </legend>
			
		<?php
			
			while($i<=$nbrquestion){
				/* pour chaque question ($quest), voir se que le joueur a choisi comme reponse ($choix),
					et la comparer avec la bonne reponse ($rep)
				*/
				$quest=$questions[$j];
				$repe=$rep[$j];
				$choix=	$_GET['select_'.$i.''];
				
				if($repe == $choix){
					// bonne reponse
					$resultat++;
				}
				else{
					echo("<div class= \"correction\"> ");
						echo("<p> Question N  ".$i." : ".$quest."</br> </p>");
						
						echo("<p> La bonne reponse est: ".$reponse[$j]."</br></br> </p>");
						
					echo("</div> ");
				}
				
				$i++;
				$j++;
			}
			
			if($resultat==$nbrquestion){
				echo("<div class= \"tout_juste\"> ");
					echo("<p> <b>Bravo vous avez fait un sans faute</b> </br> </p>");
					echo("<p> <b>Votre score est de: ".$resultat." / ".$nbrquestion."</b> </p>");
				echo("</div> ");
			}else {
				echo("<div class= \"result\"> ");
					echo("<p> <b>Votre score est de: ".$resultat." / ".$nbrquestion."</b> </p>");
				echo("</div> ");
			}
		
		?>
			
			
	</fieldset>
    
  </body>
</html>
