<?php
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	
	require_once '../Config/BD_Conn.php';

	/* recuperer les champs du formulaire */
	$login = trim($_GET['log']) ;
	$password = trim($_GET['mp']) ;
	
	/* si l'un des champs est vide */
	if(!$password || !$login){
		header('Location: ../View/Acceuil_Obli.html');
	}
	else {
			$password = md5($password);
			$admin = "admin";
			$admin = md5($admin);
			
			if (($login=='admin') &&($password==$admin)) 
			{
				/* declater la session pour l'utilisateur */
				$_SESSION['login']=$login;
				header('Location: Page_Perso_admin.php');
			} 
			else 
			{
				/* Voir Model */
				include '../Model/verif_login_password.php';

				if ( $count == 1 )
				{
					/* declater la session pour l'utilisateur */
					$_SESSION['login']=$login;
					header('Location: Page_Perso_membre.php');
				}
				else 
				{
					/* si il n'existe pas rediriger vers la page d'errur */
					header('Location: ../View/Acceuil_Err.html');	
				}
			}
			$resultrech->closeCursor();
		}
	
?>