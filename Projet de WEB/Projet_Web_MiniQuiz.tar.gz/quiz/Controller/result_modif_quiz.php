<?php
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	
	require_once '../Config/BD_Conn.php';
	
	/* recuperer le nombre de question, et le nom de la question, et le tableau des id de questions */
	$nbrqm=$_SESSION['nbrqm'];
	$nameq=$_SESSION['$nameq'];
	$id=$_SESSION['id'];
	
	$i=1;$j=0;
	while($i<=$nbrqm){
		
		/* recuperer chaque champs et le mettre dans une variable pour l'introduir dans la BD */
		$id_q=$id[$j];
		
		$quest=$_GET['q_'.$i.''];//echo("$quest </br>");
		$rep1= $_GET['r_'.$i.'1'];//echo("$rep1 </br>");
		$rep2= $_GET['r_'.$i.'2'];//echo("$rep2</br>");
		$rep3= $_GET['r_'.$i.'3'];//echo("$rep3 </br>");
		$rep4= $_GET['r_'.$i.'4'];//echo("$rep4 </br>");
		$choix=	$_GET['select_'.$i.''];//echo("$choix </br>");
		
		if(empty(trim($quest))){
			/* si on ne met pas de question, la question sera supprimer du quiz*/
			$delet = $dbh->query("delete from question where id ='".$id_q."'");
			
		}
		else{
			/* faire la modification */
			$modif_question = $dbh->query("update question set intitule='$quest', reponse1='$rep1', reponse2='$rep2', reponse3='$rep3', reponse4='$rep4', choix='$choix' where nom_quiz='$nameq' and id='$id_q'");
		}
		$i++;
		$j++;
	}
	
	
	if($_SESSION['login']=='admin'){
		header('Location: Page_Perso_admin.php');
	}
	else {
		header('Location: Page_Perso_membre_modif.php');
	}
	
	
	
?>