<?php
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	
	require_once '../Config/BD_Conn.php';
	
	
	
	/* recuperer les variables de notre sessions */
	$nbrq=$_SESSION['nbrq'];
	$nameq=$_SESSION['$nameq'];
	$proprietaire = $_SESSION['login'];
	
	/* Voir Model Pour comprendre */
	include '../Model/ajour_quiz.php';
	
	/* insertion de chaque question avec ses propositions de reponses, et sa bonne reponse*/
	$i=1;
	while($i<=$nbrq){
		$quest=$_GET['q_'.$i.''];
		$rep1= $_GET['r_'.$i.'1'];
		$rep2= $_GET['r_'.$i.'2'];
		$rep3= $_GET['r_'.$i.'3'];
		$rep4= $_GET['r_'.$i.'4'];
		$choix=	$_GET['select_'.$i.''];
		
		/* verifier si l'utilisateur a bien mis une question, dansle cas contraire ne pas ajouter la question */
		if(!empty(trim($quest))){
			$ajout_question = $dbh->query("insert into question values('','$nameq','$quest','$rep1','$rep2','$rep3','$rep4','$choix')");
		}
		$i++;
	}
	
	/* a la fin de l'ajout dans la BD, verifier si l'utilisateur est admin ou simple utilisateur pour savoir vers quelle page rediriger */
	if($_SESSION['login']=='admin'){
		header('Location: Page_Perso_admin.php');
	}
	else {
			header('Location: Page_Perso_membre.php');
	}
	
?>