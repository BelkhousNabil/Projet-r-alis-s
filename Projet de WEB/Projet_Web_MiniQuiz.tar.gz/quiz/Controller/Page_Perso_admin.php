<?php
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	
	require_once '../Config/BD_Conn.php';
	
	/* Voir le Model pour comprendre */
	include '../Model/select_quiz_membreAcces.php';
	
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Mini Quiz</title>
    <link href="../Style/style_Acceuil.css" rel="stylesheet">
	<link rel="stylesheet" media="screen and (max-width: 1200px) and (min-width: 870px)" href="../Style/style_quiz-deux1.css" />
	<link rel="stylesheet" media="screen and (max-width: 869px) and (min-width: 710px)" href="../Style/style_quiz-deux2.css" />
	<link rel="stylesheet" media="screen and (max-width: 709px) and (min-width: 550px)" href="../Style/style_quiz-deux3.css" />
	<link rel="stylesheet" media="screen and (max-width: 549px) and (min-width: 350px)" href="../Style/style_quiz-deux4.css" />


  </head>

  <body>
  	<nav>
  		<ul>
			<li class = "vide"> </li>
			<li class = "li_gest"> <a href="redirection.php"> <?php echo("<b>Bienvenue ".$_SESSION['login']."</b>"); ?> </a> </li>
			<li class = "vide"> </li> 
  			<li class = "li_gest" > <a href="suppression_compte.php">Supprimer utilisateur</a> </li>
  			<li class = "vide"> </li> 
  			<li> <a href="suppression_quiz.php">Supprimer Quiz</a> </li>
  			<li class = "vide"> </li> 
  			<li> <a href="logout.php">Se déconnecter</a> </li>
  		</ul>
  	</nav>
	
	<div class="Etat_gestion">
		<fieldset class="Liste_membre">
		<legend>Liste des membres</legend>
			<?php
				$i=0;
				echo( "<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" align=\"center\">\n" );
				echo( "<tr>
							<td><div align=\"center\"> Compte N </div></td>
							<td><div align=\"center\"> Pseudo utilisateur </div></td>
						</tr>" 
					);
					
					while( $result = $resultrech->fetch() )
					{
						echo( "<tr>\n" );
							echo( "<td><div align=\"center\"> N° ".++$i."</div></td>\n" );
							echo( "<td><div align=\"center\">".$result[0]."</div></td>\n" );
						echo( "</tr>\n" );
					}
				 
				echo( "</table><br>\n" );
				$resultrech->closeCursor();
			?>
			
			
		</fieldset>
		
		<fieldset class="Liste_quiz">
			<legend>Liste des quiz</legend>
			
			<?php
				$i=0;
				echo( "<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" align=\"center\">\n" );
				echo( "<tr>
							<td><div align=\"center\"> Quiz N </div></td>
							<td><div align=\"center\"> Nom du Quiz </div></td>
							<td><div align=\"center\"> Proprietaire </div></td>
						</tr>" 
					);
					
					while( $result = $resultrech2->fetch() )
					{
						echo( "<tr>\n" );
							echo( "<td><div align=\"center\"> N° ".++$i."</div></td>\n" );
							echo( "<td><div align=\"center\">".$result[0]."</div></td>\n" );
							echo( "<td><div align=\"center\">".$result[1]."</div></td>\n" );
						echo( "</tr>\n" );
					}
				 
				echo( "</table><br>\n" );
				$resultrech2->closeCursor();
			?>
				
		</fieldset>
	</div>
	
	
  </body>
</html>

