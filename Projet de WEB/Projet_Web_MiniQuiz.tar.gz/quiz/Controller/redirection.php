<?php
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	
	if($_SESSION['login']=='admin'){
		header('Location: Page_Perso_admin.php');
	}
	else {
		header('Location: Page_Perso_membre.php');
	}
?>