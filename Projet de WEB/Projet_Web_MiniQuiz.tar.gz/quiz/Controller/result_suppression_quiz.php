<?php
	
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	
	require_once '../Config/BD_Conn.php';

	$nameq = $_GET['select_jeu'];
	
	/* suppression du quiz selectionner et de toutes ses questions */
	$supp_quiz = $dbh->query("delete from quiz where nom ='".$nameq."'");   
	$supp_quest = $dbh->query("delete from question where nom_quiz ='".$nameq."'");   
	
	if($_SESSION['login']=='admin'){
	header('Location: Page_Perso_admin.php');
	}
	else {
		header('Location: Page_Perso_membre.php');
	}
	
?>