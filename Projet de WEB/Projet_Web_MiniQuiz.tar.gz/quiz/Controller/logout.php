<?php
	session_start();
	session_destroy();
	/* apres le deconnexion rediriger vers la page d'acceuil */
	header('Location: ../View/Acceuil.html');
?>