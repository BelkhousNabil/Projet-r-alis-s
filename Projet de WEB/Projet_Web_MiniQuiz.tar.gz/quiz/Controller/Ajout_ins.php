<?php
	/*Commencer une session, et voir si il existe une valeur dans le tableau associative a la clef 'login', sinon rediriger vers l'acceuil*/
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	/*inclure la BD*/
	require_once '../Config/BD_Conn.php';
	
	/* recuperer les valeurs du formulaire */
	$pseudo = trim($_GET['pse']) ;
	$nom = $_GET['nom'] ;
	$prenom = $_GET['pren'] ;
	$email = trim($_GET['email']) ;
	$password = trim($_GET['mp']) ;
	
	/*verifier si l'un des champs donnees sont vides, si c'est le cas rediriger vers une page d'erreur*/
	if(!$pseudo || !$nom ||!$prenom || !$email || !$password){
		header('Location: ../View/Inscription_Obli.html');
	}
	else{
			/* crypter mon mot de passe */
			$password = md5($password) ;
		
			/* Voir Le Model Pour comprendre */
			include '../Model/verif_mail_pseudo.php';
			
			if ( $count == 1 )
			{ 
				/*dans le cas ou le mail existe déja donc est associer a un compte
					rediriger vers la page d'inscritpion en affichant un message d'erreur*/
				header('Location: ../View/Inscription_Err.html');	
			}	
			elseif($count == 0)
			{	/* si le mail n'existe pas*/
				if ($count1 == 1)
				{/*si le  pseudo est associe a un compte
					rediriger vers la page d'inscritpion en affichant un message d'erreur*/
					header('Location: ../View/Inscription_Err_pseu.html');
				}
				else 
				{
					/* Voir Le Model Pour comprendre */
					include '../Model/ajour_membre.php';
					
					header('Location: ../View/Acceuil_ins.html');
				}
				
			}
		
		$resultrech->closeCursor();
		
	}
	
	
?>