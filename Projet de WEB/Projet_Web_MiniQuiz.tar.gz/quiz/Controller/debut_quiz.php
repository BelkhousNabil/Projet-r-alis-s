<?php
	session_start();
	
	require_once '../Config/BD_Conn.php';
	
	/*recuper le nom de quiz choisi*/
	$quiz=$_GET['select_jeu'] ;

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Mini Quiz</title>
    <link href="../Style/style_Acceuil.css" rel="stylesheet">
	<link rel="stylesheet" media="screen and (max-width: 869px) and (min-width: 710px)" href="../Style/style_creat_quiz1.css" />
	<link rel="stylesheet" media="screen and (max-width: 709px) and (min-width: 550px)" href="../Style/style_creat_quiz2.css" />
	<link rel="stylesheet" media="screen and (max-width: 549px) and (min-width: 350px)" href="../Style/style_creat_quiz3.css" />
    
	<script>
		function griser(champs){
			champs.style.visibility = "hidden";
		}
	</script>
	
  </head>

  <body>
  	<nav>
  		<?php	
			echo("<ul>");
				echo("<li class = \"vide\"> </li>");
				echo("<li> <a href=\"choix_quiz.php\">Mini Quiz</a> </li>");
				echo("<li class = \"vide\"> </li>");
				echo("<li class = \"li_gest\"> <a href=\"redirection.php\"> Acceuil </a> </li>");
				echo("<li class = \"vide\"> </li>");
			echo("</ul>");
		?>
  	</nav>

	<fieldset class = "fied">
		<?php echo("<legend> $quiz </legend>"); ?>
			<form method = "GET" action = "resultat_quiz.php" name = "form_jouer_quiz">
					
				<?php
						/* Voir Model */
						include '../Model/select_count_question_quiz.php';

						/* sauvegarder le nombre de question dans une la session */
						$_SESSION['nbrquestion']= $count;
						$resultrech->closeCursor();
						
						/* Voir Model */
						include '../Model/select_question_quiz.php';
				
						/* pour chaque question, et chaque une de ses reponses, les mettre dans un tableau avec a la fin une liste deroulante pour choisir la bonne reponse */
						$i=0;
						echo( "<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" align=\"center\">\n" );
						while( $resultat = $champs->fetch() )
						{
							/* stocker l'id de la  bonne reponse de chaque question dans un tableau $rep[] */
							$rep[]=$resultat[5];
							
							/* stocker la bonne reponse de chaque question dans un tableau $reponse[]*/
							if($resultat[5]==1){
								$reponse[]=$resultat[1];
							}
							if($resultat[5]==2){
								$reponse[]=$resultat[2];
							}
							if($resultat[5]==3){
								$reponse[]=$resultat[3];
							}
							if($resultat[5]==4){
								$reponse[]=$resultat[4];
							}
							
							/* stocker la questions elle meme dans un tableau $questions[] */
							$questions[]=$resultat[0];
							
							echo( "<tr>\n" );
								echo( "<td colspan =2><div align=\"center\"> Question N° ".++$i.": ".$resultat[0]." "."</div></td>\n" );
							echo( "</tr>\n" );
								
							echo( "<tr>\n" );
								echo( "<td> <b>1:</b> <div align=\"center\">".$resultat[1]."</div></td>\n" );
								echo( "<td> <b>2:</b> <div align=\"center\">".$resultat[2]."</div></td>\n" );
							echo( "</tr>\n" );
							
							echo( "<tr>\n" );
								echo( "<td> <b>3:</b> <div align=\"center\">".$resultat[3]."</div></td>\n" );
								echo( "<td> <b>4:</b> <div align=\"center\">".$resultat[4]."</div></td>\n" );
							echo( "</tr>\n" );
							
							echo( "<tr>\n" );
								echo( "<td colspan =2><div align=\"center\"> <input type=\"number\" id=\"select_".$i."\" name=\"select_".$i."\" min=\"1\" max=\"4\" onblur=\"griser(this)\" > </div></td>\n" );
							echo( "</tr>\n" );
						}
						/* a la fin du quiz stocker le tableau de bonne reponses pour verifier avec les reponse donnee par l'utilisateur a la fin du quiz (apres envoi du formulaire) */
						$_SESSION['reponse']=$reponse;
						$_SESSION['rep']=$rep;
						/* a la fin du quiz stocker le tableau de question pour menter les erreurs et leurs corrections a l'utilisateur a la fin du quiz (apres envoi du formulaire) */
						$_SESSION['questions']=$questions;
						
						echo( "</table><br>\n" );
				?>

				<input type='submit' name='corri' id='corri' value='Corriger' >					
			</form>
	</fieldset>
    
  </body>
</html>
