<?php
	
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	
	require_once '../Config/BD_Conn.php';

	$login = $_GET['select_user'];
	
	/* supprimier le user selectionner, et tout ses quiz et les questions des quiz*/
	$supp_membre = $dbh->query("delete from membre_acces where login ='".$login."'");   
	$supp_membre_acces = $dbh->query("delete from membre where pseudo ='".$login."'"); 
	
	$resultrech = $dbh->query("select nom from quiz where proprietaire='$login'"); 
	while( $result = $resultrech->fetch() )
	{
		$supp_quest = $dbh->query("delete from question where nom_quiz ='".$result[0]."'"); 
	}
	$supp_quiz = $dbh->query("delete from quiz where proprietaire ='".$login."'");   
	
	header('Location: Page_Perso_admin.php');
	
	$resultrech->closeCursor();
?>