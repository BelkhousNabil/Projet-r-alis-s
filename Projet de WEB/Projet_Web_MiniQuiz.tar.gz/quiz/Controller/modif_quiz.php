<?php
	
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	
	require_once '../Config/BD_Conn.php';
	
	/* recuperer le proprietaire */
	$prop = $_SESSION['login'];
	
	/* recuperer le nom du quiz */
	$nameq = $_GET['select_jeu'];
	
		
	/* sauvegarder la question */
	$_SESSION['$nameq']= $nameq;
	
	/* Voir Model */
	include '../Model/select_count_quiz_prop.php';
	
	$i=0;
	$cpt=0;
	
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Mini Quiz</title>
    <link href="../Style/style_Acceuil.css" rel="stylesheet">
	<link rel="stylesheet" media="screen and (max-width: 869px) and (min-width: 710px)" href="../Style/style_creat_quiz1.css" />
	<link rel="stylesheet" media="screen and (max-width: 709px) and (min-width: 550px)" href="../Style/style_creat_quiz2.css" />
	<link rel="stylesheet" media="screen and (max-width: 549px) and (min-width: 350px)" href="../Style/style_creat_quiz3.css" />

  </head>

  <body>
  	<nav>
  		<ul>
			<li class = "vide"> </li>
			<li class = "li_gest"> <a href="redirection.php"> Acceuil </a> </li>
			<li class = "vide"> </li>
  			<li> <a href="choix_quiz.php">Mini Quiz</a> </li>
  			<li class = "vide"> </li> 
			<li> <a href="../View/Ajout_quiz.html">Ajouter Quiz</a> </li>
			<li> <a href="modification_quiz.php">Modifier Quiz</a> </li>
			<li> <a href="suppression_quiz.php">Supprimer Quiz</a> </li>
			<li class = "vide"> </li> 
			<li> <a href="logout.php">Se déconnecter</a> </li>
  		</ul>
  	</nav>

	<fieldset class = "fied">
		<legend> Modification de Quiz </legend>
			<form method = "GET" action = "result_modif_quiz.php" name = "form_result_modif_quiz">
					
<?php
	if ( $count == 1 )
	{
		/* Voir Model */
		include '../Model/select_ajout_question.php';
		
		/* sauvegarder le nombre de questions du quiz */
		$_SESSION['nbrqm']= $countnbr;
		
		/* stocker l'id de chaque question dans un table php */
		$id=array();
		
		while( $resultat = $champs->fetch() )
		{	$id[]=$resultat[6];
			echo("<div class = \"div-q\">");
			
				echo("<div class = \"div-l\">");
					echo("<div class = \"div-g\">");
						echo("<label>Question ".++$i." : </label>");
					echo("</div>");
					echo("<div class = \"div-d\">");
						echo("<input type=\"text\" value=\"$resultat[0]\" id=\"q_".$i."\" name=\"q_".$i."\">");
					echo("</div>");
				echo("</div>");				
				
				$q=0; $r=0; $c=0;
				while ($q<4){
					echo("<div class = \"div-l\">");
						echo("<div class = \"div-g\">");
							echo("<label>Reponse ".++$q." : </label>");
						echo("</div>");
						echo("<div class = \"div-dr\">");
							echo("<input type=\"text\" id=\"r_".$i."".++$r."\" name=\"r_".$i."".$r."\" value=\"$resultat[$q]\" >");
						echo("</div>");
					echo("</div>");
				} 
				
				echo("<div class = \"div-l\">"); 
					echo("<div class = \"div-g\">"); 
						echo("<label>Bonne reponse : </label>"); 
					echo("</div>"); 
					echo("<div class = \"div-d\">");
						echo("<input type=\"number\" value=\"$resultat[5]\" id=\"select_".$i."\" name=\"select_".$i."\" min=\"1\" max=\"4\"> ");
					echo("</div>");
				echo("</div>");
				
			echo("</div>");
			
		}
		$_SESSION['id']=$id;
	}
	
	$resultrech->closeCursor();
?>

				<input type='submit' name='modif' id='modif' value='Modifier' >					
			</form>
	</fieldset>
    
  </body>
</html>
