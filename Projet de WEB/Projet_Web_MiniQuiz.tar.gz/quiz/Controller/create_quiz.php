		<?php
			session_start();
			if(!$_SESSION['login'])
			{
				header('Location: ../View/Acceuil.html');
			}
			
			require_once '../Config/BD_Conn.php';
			
			/* recuperer les valeurs du formulaire */
			$nameq = trim($_GET['q_name']) ;
			$nbrq = trim($_GET['nbq']) ;
			
			/* verifier que tout les champs ne sont pas vide sinon rediriger vers une page d'erreur*/
			if(!$nameq || !$nbrq){
				header('Location: ../View/ajout_quiz_Err.html');
			}
			else {
			/* recuperer la question et le nombre de question du quiz et les stocker dans une le tableau associative de session*/
			$_SESSION['nbrq']=$nbrq;
			$_SESSION['$nameq']=$nameq;
			
			/* cpt servira pour le parcours de toutes les question
				i servira pour nommer les champs de questions, bonnes reponses, et les propositions de reponses
				r servira pour nommer les champs propositions de reponses
			*/
			$cpt=0;
			$i=0;
			$r=0;
			
			/* recuperer le poprietaire de la session */
			$proprietaire=$_SESSION['login'];
			
			/* Voir Model Pour comprendre */
			include '../Model/verif_quiz_existe.php';
			
			if ($count == 1)
			{	/*ce nom de quiz existe deja rediriger vers la page d'ajout de quiz en affichant un message d'erreur */
				header('Location: ../View/Ajout_quiz_Err_name.html');
			}
		//	else 
			//{	
				/* Voir Model Pour comprendre */
			//	include '../Model/ajour_quiz.php';
			//}
			
			$rech->closeCursor();

		?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Mini Quiz</title>
		<link href="../Style/style_Acceuil.css" rel="stylesheet">
		<link rel="stylesheet" media="screen and (max-width: 869px) and (min-width: 710px)" href="../Style/style_creat_quiz1.css" />
		<link rel="stylesheet" media="screen and (max-width: 709px) and (min-width: 550px)" href="../Style/style_creat_quiz2.css" />
		<link rel="stylesheet" media="screen and (max-width: 549px) and (min-width: 350px)" href="../Style/style_creat_quiz3.css" />

	</head>

	<body>
		<nav>
			<ul>
				<li class = "vide"> </li>
				<li class = "li_gest"> <a href="redirection.php"> Acceuil </a> </li>
				<li class = "vide"> </li>
				<li> <a href="choix_quiz.php">Mini Quiz</a> </li>
				<li class = "vide"> </li> 
				<li> <a href="../View/Ajout_quiz.html">Ajouter Quiz</a> </li>
				<li> <a href="modification_quiz.php">Modifier Quiz</a> </li>
				<li> <a href="suppression_quiz.php">Supprimer Quiz</a> </li>
				<li class = "vide"> </li> 
				<li> <a href="logout.php">Se déconnecter</a> </li>
			</ul>
		</nav>
		
		
		<fieldset class = "fied">
			<legend> Création du Quiz </legend>
				<form method = "GET" action = "create_quiz_2.php" name = "form_construct_quiz">
				
					<?php while($cpt<$nbrq){?>
					
						<?php echo("<div class = \"div-q\">"); ?>
						
							<?php echo("<div class = \"div-l\">"); ?>
								<?php echo("<div class = \"div-g\">"); ?>
									<?php echo("<label>Question".++$i." </label>"); ?>
								<?php echo("</div>"); ?>
								<?php echo("<div class = \"div-d\">"); ?>
									<?php echo("<input type=\"text\" id=\"q_".$i."\" name=\"q_".$i."\">") ?> <?php /*echo("id=\"q_".$i."\"");*/ ?>
								<?php echo("</div>"); ?>
							<?php echo("</div>"); ?>	
							
							
							
							<?php $q=0; $r=0; $c=0;?>
							<?php while ($q<4){?>
								<?php echo("<div class = \"div-l\">"); ?>
									<?php echo("<div class = \"div-g\">"); ?>
										<?php echo("<label>Reponse".++$q." </label>"); ?>
									<?php echo("</div>"); ?>
									<?php echo("<div class = \"div-dr\">"); ?>
										<?php echo("<input type=\"text\" id=\"r_".$i."".++$r."\" name=\"r_".$i."".$r."\">") ?> <?php /*echo(" id=\"r_".$i."".$r."\" "); */?>
									<?php echo("</div>"); ?>
								<?php echo("</div>"); ?>
							<?php } ?>
							
							<?php echo("<div class = \"div-l\">"); ?>
								<?php echo("<div class = \"div-g\">"); ?>
									<?php echo("<label>Bonne reponse </label>"); ?>
								<?php echo("</div>"); ?>
								<?php echo("<div class = \"div-d\">"); ?>
									<?php echo("<input type=\"number\" id=\"select_".$i."\" name=\"select_".$i."\" min=\"1\" max=\"4\"> "); ?>
								<?php echo("</div>"); ?>
							<?php echo("</div>"); ?>
							
						<?php echo("</div>"); ?>
						
					<?php $cpt++;}?>

	<?php 
		}
	?>
					<input id="btvalid" type='submit' name='valid' id='valid' value="Valider"  >
				</form>
		</fieldset>
	</body>
</html>