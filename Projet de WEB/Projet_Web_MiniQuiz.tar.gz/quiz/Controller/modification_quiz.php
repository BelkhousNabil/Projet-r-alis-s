<?php
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	
	/* recuperer le proprietaire de la session */
	$prop = $_SESSION['login'];
	
	require_once '../Config/BD_Conn.php';
	
	/* Voir Model */
	include '../Model/modif_quiz_question.php';
	
	if($coun !=0){
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Mini Quiz</title>
    <link href="../Style/style_Acceuil.css" rel="stylesheet">
	<link rel="stylesheet" media="screen and (max-width: 1200px) and (min-width: 870px)" href="../Style/style_quiz-deux1.css" />
	<link rel="stylesheet" media="screen and (max-width: 869px) and (min-width: 710px)" href="../Style/style_quiz-deux2.css" />
	<link rel="stylesheet" media="screen and (max-width: 709px) and (min-width: 550px)" href="../Style/style_quiz-deux3.css" />
	<link rel="stylesheet" media="screen and (max-width: 549px) and (min-width: 350px)" href="../Style/style_quiz-deux4.css" />


  </head>

  <body>
  	<nav>
  		<ul>
			<li class = "vide"> </li>
			<li class = "li_gest"> <a href="redirection.php"> Acceuil </a> </li>
			<li class = "vide"> </li>
  			<li> <a href="choix_quiz.php">Mini Quiz</a> </li>
  			<li class = "vide"> </li> 
			<li> <a href="../View/Ajout_quiz.html">Ajouter Quiz</a> </li>
			<li> <a href="modification_quiz.php">Modifier Quiz</a> </li>
			<li> <a href="suppression_quiz.php">Supprimer Quiz</a> </li>
			<li class = "vide"> </li> 
			<li> <a href="logout.php">Se déconnecter</a> </li>
  		</ul>
  	</nav>

	<fieldset>
		<legend> Modification de Quiz </legend>
			<form method = "GET" action = "modif_quiz.php" name = "form_modif_quiz">
				 
				<div class = "div-l">
					<div class = "div-g">
						<label> Quiz </label>
					</div>
					<div class = "div-d">
						<select name="select_jeu" id="select_jeu" size="1">
							<?php
								while( $result = $resultrech2->fetch() )
								{
									echo("<option>$result[0]</option>");
								}
								
				}
				else {
					header('Location: ../View/quiz_introuvable.html');
				}
				$resultrech2->closeCursor();
								
							?>
						</select>
					</div>
				</div>	
				
				<input type='submit' name='modif' id='modif' value='Modifier' >	
			</form>
	</fieldset>
    
  </body>
</html>

