<?php
	session_start();
	if(!$_SESSION['login'])
	{
		header('Location: ../View/Acceuil.html');
	}
	$prop = $_SESSION['login'];
	
	require_once '../Config/BD_Conn.php';
	
	/* Voir Le model pour comprendre*/
	include '../Model/select_count_membreAcces.php';
	
	if($coun !=0){
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Mini Quiz</title>
    <link href="../Style/style_Acceuil.css" rel="stylesheet">
	<link rel="stylesheet" media="screen and (max-width: 1200px) and (min-width: 870px)" href="../Style/style_quiz-deux1.css" />
	<link rel="stylesheet" media="screen and (max-width: 869px) and (min-width: 710px)" href="../Style/style_quiz-deux2.css" />
	<link rel="stylesheet" media="screen and (max-width: 709px) and (min-width: 550px)" href="../Style/style_quiz-deux3.css" />
	<link rel="stylesheet" media="screen and (max-width: 549px) and (min-width: 350px)" href="../Style/style_quiz-deux4.css" />


  </head>

  <body>
  	<nav>
  		<?php
		if($_SESSION['login']=='admin'){
			echo("<ul>");
				echo("<li class = \"vide\"> </li>");
				echo("<li class = \"li_gest\"> <a href=\"redirection.php\"> Acceuil </a> </li>");
				echo("<li class = \"vide\"> </li>");
				echo("<li class = \"li_gest\" > <a href=\"suppression_compte.php\">Supprimer utilisateur</a> </li>");
				echo("<li class = \"vide\"> </li>");
				echo("<li> <a href=\"suppression_quiz.php\">Supprimer Quiz</a> </li>");
				echo("<li class = \"vide\"> </li>"); 
				echo("<li> <a href=\"logout.php\">Se déconnecter</a> </li>");
			echo("</ul>");
		}
		else {
			echo("<ul>");
			echo("<li class = \"vide\"> </li>");
			echo("<li class = \"li_gest\"> <a href=\"redirection.php\"> <b>Bienvenue ".$login."</b> </a> </li>");
			echo("<li class = \"vide\"> </li>");
  			echo("<li> <a href=\"choix_quiz.php\">Mini Quiz</a> </li>");
  			echo("<li class = \"vide\"> </li>");
			echo("<li> <a href=\"../View/Ajout_quiz.html\">Ajouter Quiz</a> </li>");
			echo("<li> <a href=\"modification_quiz.php\">Modifier Quiz</a> </li>");
			echo("<li> <a href=\"suppression_quiz.php\">Supprimer Quiz</a> </li>");
			echo("<li class = \"vide\"> </li>"); 
			echo("<li> <a href=\"logout.php\">Se déconnecter</a> </li>");
			echo("</ul>");
		}
  		
	?>
  	</nav>

	<fieldset>
		<legend> Suppression de compte  </legend>
			<form method = "GET" action = "result_suppression_compte.php" name = "form_suppr_users">
				 
				<div class = "div-l">
					<div class = "div-g">
						<label> Compte  </label>
					</div>
					<div class = "div-d">
						<select name="select_user" id="select_user" size="1">
							<?php
								while( $result = $resultrech2->fetch() )
								{
									echo("<option>$result[0]</option>");
								}
			}
			else {
				header('Location: ../View/suppression_user_impossible.html');
			}
			$resultrech2->closeCursor();
							?>
						</select>
					</div>
				</div>	
				
              	<input type='submit' name='supp' id='supp' value="Supprimer"  >
						
			</form>
	</fieldset>
    
  </body>
</html>

