package com.gil.master1.setting;

import java.util.ArrayList;

/**
 * SettingsTree Class that contain the list of setting and there methods
 * 
 * @author anouar & nabil
 * @version 1.0
 * @date 02/01/2015
 */
public class SettingsTree {
	
	private Group root;
	private Group cursor;
	
	/**
	 * SettingsTree Default constructor 
	 */
	public SettingsTree(){
		this.root = new Group();
		this.cursor = root; 
	}
	
	public ISetting getSettingByKeys(Group cursor, String keys){
		keys = keys.trim();
		if(keys.equals("")){
			if(!keys.contains(".")){
				for(ISetting st : cursor.getListSettingChild()){
					if(st.getKey().equals(keys)){
						return st;
					}
				}
			}
			else{
				String[] keyTab = keys.split("."); 
				Group tmpCursur = cursor;
				ISetting tmp;
				for(String key : keyTab){
					tmp = tmpCursur.getSettingChildByKey(key);
					if(tmp == null){ 
						return null;
					}
					else if(key.equals(keyTab[keyTab.length -1])){
						return tmp;
					}
					else if(!tmp.isKeyOfSetting()){
						tmpCursur = (Group)tmp;
					}
					else{
						return null;
					}
				}
				
				return null;
			}
		}
		
		return null;
	}
	
	public boolean addSetting(String keys, ValueType value){
		keys = keys.trim();
		if(!keys.equals("")){
			String[] groupTab = keys.contains(".") ? keys.split(".") :  new String[]{keys}; 
			ISetting settingGroupCursor = cursor;
			int index = 0, lastIndex = groupTab.length -1;
			for(String gr : groupTab){
				ISetting st = getSettingByKeys((Group)settingGroupCursor, gr);
				if(st != null){
					if(st.isKeyOfSetting()){
						if(index == groupTab.length -1 && value != null){
							((Key)st).setValue(value);
							return true;
						}
						return false;
					}
					else if(!st.isKeyOfSetting()){
						if(index == lastIndex && value != null){
							return false; // on peut pas attribuer un valeur à un groupe 
						}
						else{
							settingGroupCursor = st;
						}
					}
				}
				else{
					if(index == lastIndex){
						if(value != null){
							return ((Group)settingGroupCursor).addSettingChild(new Key(gr, value));
						}
						else{
							return ((Group)settingGroupCursor).addSettingChild(new Group(gr));
						}
					}
					else{
						Group tmp = new Group(gr);
						((Group)settingGroupCursor).addSettingChild(tmp);
						settingGroupCursor = tmp;
					}
				}
			}
		}
		return false;
	}
	
	
	
	
}
