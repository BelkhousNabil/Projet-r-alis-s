package com.gil.master1.setting;

import java.util.ArrayList;

/**
 * Group - Class that represent Group object
 * 
 * @author anouar & nabil
 * @version 1.0
 * @date 02/01/2015
 */
public class Group implements ISetting {
	
	private String key;
	private ArrayList<ISetting> listSettingChild;
	private ISetting settingParent;
	private boolean isKeyOfSetting;
	
	
	/**
	 * Group The default constructor
	 */
	public Group(){
		setIsKeyOfSetting(false);
		listSettingChild = new ArrayList<ISetting>();
	}
	
	/**
	 * Group The default constructor
	 * 
	 * @param key The content value of Key
	 */
	public Group(String key){
		this.key = key;
		setIsKeyOfSetting(false);
		listSettingChild = new ArrayList<ISetting>();
	}
	

	/**
	 * getSettingChild Get the setting child instance
	 * 
	 * @return the settingChild
	 */
	public ArrayList<ISetting> getListSettingChild() {
		return listSettingChild;
	}


	/**
	 * setSettingChild Set the value of setting child instance
	 * 
	 * @param settingChild the settingChild to set
	 */
	public void setListSettingChild(ArrayList<ISetting> listSettingChild) {
		this.listSettingChild = listSettingChild;
	}
	
	/**
	 * addSettingChild Add setting element to setting
	 * 
	 * @param setting ISetting element
	 * @return boolean Return true if element is inserted else false
	 */
	public boolean addSettingChild(ISetting setting){
		return listSettingChild.add(setting);
	}
	
	/**
	 * getSettingChildByKey Retrive the setting child using Key
	 * 
	 * @param key The key value
	 * @return Return the setting object if exist else null
	 */
	public ISetting getSettingChildByKey(String key){
		for(ISetting st : listSettingChild){
			if(st.getKey().equals(key)){
				return st;
			}
		}
		
		return null;
	}
	
	/**
	 * getSettingParent Get the parent of this instant
	 * 
	 * @return the settingParent
	 */
	public ISetting getSettingParent() {
		return settingParent;
	}


	/**
	 * setSettingParent Set the parent of this instance
	 * 
	 * @param settingParent the settingParent to set
	 */
	public void setSettingParent(ISetting settingParent) {
		this.settingParent = settingParent;
	}

	/* (non-Javadoc)
	 * @see com.gil.master1.setting.ISetting#getKey()
	 */
	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return this.key;
	}

	/* (non-Javadoc)
	 * @see com.gil.master1.setting.ISetting#setKey(java.lang.String)
	 */
	@Override
	public void setKey(String key) {
		// TODO Auto-generated method stub
		this.key = key;
	}
	
	/* (non-Javadoc)
	 * @see com.gil.master1.setting.ISetting#setIsKeyOfSetting(boolean)
	 */
	@Override
	public boolean isKeyOfSetting() {
		// TODO Auto-generated method stub
		return this.isKeyOfSetting;
	}

	/* (non-Javadoc)
	 * @see com.gil.master1.setting.ISetting#isKeyOfSetting()
	 */
	@Override
	public void setIsKeyOfSetting(boolean isKeyOfSetting) {
		// TODO Auto-generated method stub
		this.isKeyOfSetting = isKeyOfSetting;
	}
}
